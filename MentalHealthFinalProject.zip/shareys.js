var signMeUp= $('.sign');
signMeUp.on("click", doSomething);
function doSomething(event) {
   event.preventDefault();
   alert("Thank you for subscrbing to the Four Corners Newsletter!!")
};


  
   